
#ifndef POINT_H
#define POINT_H

typedef struct {
    // TODO
} point_t;

#endif //POINT_H
