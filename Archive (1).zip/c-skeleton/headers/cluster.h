
#ifndef CLUSTER_H
#define CLUSTER_H

typedef struct {
    // TODO
} cluster_t;

#endif //CLUSTER_H
