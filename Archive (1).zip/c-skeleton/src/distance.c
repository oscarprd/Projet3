
#include "../headers/distance.h"

int64_t squared_manhattan_distance(const point_t *p1, const point_t *p2) {
    // TODO
    return 42;
}


int64_t squared_euclidean_distance(const point_t *p1, const point_t *p2) {
    // TODO
    return 42;
}

